# AlphaTrial: Quantitative Strategy Backtesting & Validation Platform
**QUANTACTIVE — CODE CONFLUX**  
*Organized by Business Strategy and Analytics Club (BSAC), MNNIT Allahabad*  
**Problem Statement:** PS 01 — Build, Backtest & Validate a Trading Strategy

---

## 🏛️ 1. Problem Understanding & System Architecture

### The Core Problem
Traders often develop rule-based quantitative strategies using technical indicators and price patterns. However, strategies that appear spectacularly profitable on historical backtests frequently fail in real-world live trading due to:
1. **Unmodeled Execution Friction:** Transaction fees, exchange levies, and adverse slippage erode paper alpha.
2. **Look-Ahead Bias:** Accidental inclusion of future price data (e.g., executing at Bar $T$ Close using signals generated on Bar $T$ Close).
3. **Overfitting & Curve Fitting:** Over-tuning hyperparameters on historical noise that cannot generalize to unseen future market periods.
4. **Regime Vulnerability:** Strategies tuned during persistent bull markets suffering catastrophic liquidations during bear crashes or choppy consolidation.

### AlphaTrial Solution
AlphaTrial provides an institutional-grade, mathematically sound backtesting and validation engine with:
- Strict **$T+1$ Open execution** guaranteeing zero look-ahead bias.
- Explicit modeling of **commission fees and adverse slippage**.
- Portfolio cash accounting preventing unconstrained leverage.
- Non-overlapping **In-Sample vs. Out-of-Sample validation** with a **Sharpe Degradation Index**.
- **Walk-forward rolling-window analysis** and **macro market regime decomposition**.
- A **Machine Learning regime classifier** filtering whipsaws.

---

## 📋 2. Feature Implementation Status Matrix (BSAC Section 8 Compliance)

| Category | Requirement | Status | Module / File Reference |
| :--- | :--- | :---: | :--- |
| **Basic** | Import stock prices & volumes from CSV | **`[Implemented]`** | [`data/data_loader.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/data/data_loader.py) |
| **Basic** | Moving Average Crossover (SMA & EMA) | **`[Implemented]`** | [`strategies/moving_average.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/moving_average.py) |
| **Basic** | RSI Mean-Reversion Strategy | **`[Implemented]`** | [`strategies/rsi_strategy.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/rsi_strategy.py) |
| **Basic** | Momentum (Rate of Change) Strategy | **`[Implemented]`** | [`strategies/momentum_strategy.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/momentum_strategy.py) |
| **Basic** | Realistic Transaction Costs & Cash Limits | **`[Implemented]`** | [`core/simulator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/simulator.py) |
| **Basic** | Cumulative Return, Sharpe, MaxDD, Win Rate | **`[Implemented]`** | [`core/metrics.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/metrics.py) |
| **Basic** | Buy-and-Hold Benchmark Comparison Chart | **`[Implemented]`** | [`ui/charts.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/ui/charts.py) |
| **Advanced** | In-Sample vs. Out-of-Sample Evaluation | **`[Implemented]`** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Walk-Forward / Rolling-Window Validation | **`[Implemented]`** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Parameter Grid Search on Historical Data | **`[Implemented]`** | [`core/optimizer.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/optimizer.py) |
| **Advanced** | Market Regime Performance Decomposition | **`[Implemented]`** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Advanced** | Machine Learning Direction & Regime Model | **`[Implemented]`** | [`strategies/ml_strategy.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/strategies/ml_strategy.py) |
| **Brownie** | Fee Sensitivity Shock (Friction Erosion) | **`[Implemented]`** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Brownie** | Overfitting Alert & Degradation Index | **`[Implemented]`** | [`core/validator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/validator.py) |
| **Brownie** | Risk-Adjusted Comparison (Sortino, Calmar) | **`[Implemented]`** | [`core/metrics.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/metrics.py) |
| **Brownie** | Look-Ahead Bias Prevention Guarantee | **`[Implemented]`** | [`core/simulator.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/core/simulator.py) |
| **Brownie** | Executive Tear Sheet & Failure Modes Report | **`[Implemented]`** | [`ui/report_exporter.py`](file:///c:/Users/hp/Downloads/Desktop/BSAC%20Alphatrials/ui/report_exporter.py) |

---

## 📐 3. Quantitative Correctness & Mathematical Formulations

All financial metrics adhere to quantitative finance standards:

### 1. Cumulative Return ($R_{\text{cum}}$)
$$R_{\text{cum}} = \frac{V_{\text{final}} - V_{\text{initial}}}{V_{\text{initial}}} \times 100\%$$

### 2. Compound Annual Growth Rate (CAGR)
$$\text{CAGR} = \left(\frac{V_{\text{final}}}{V_{\text{initial}}}\right)^{\frac{252}{N_{\text{trading\_days}}}} - 1$$

### 3. Annualized Volatility ($\sigma_{\text{ann}}$)
$$\sigma_{\text{ann}} = \sigma\left(R_{\text{daily}}\right) \times \sqrt{252}$$

### 4. Sharpe Ratio ($S$)
Assuming annualized risk-free benchmark rate $R_f = 5.0\%$:
$$R_{f,\text{daily}} = (1 + R_f)^{\frac{1}{252}} - 1$$
$$S = \frac{\mu(R_{\text{daily}} - R_{f,\text{daily}})}{\sigma(R_{\text{daily}})} \times \sqrt{252}$$

### 5. Sortino Ratio
Penalizes strictly negative deviations (downside risk):
$$\text{Sortino} = \frac{\mu(R_{\text{daily}} - R_{f,\text{daily}})}{\sigma\left(\min(R_{\text{daily}} - R_{f,\text{daily}}, 0)\right)} \times \sqrt{252}$$

### 6. Maximum Drawdown (MDD)
$$\text{Peak}_t = \max_{\tau \le t} V_\tau$$
$$\text{DD}_t = \frac{V_t - \text{Peak}_t}{\text{Peak}_t}$$
$$\text{MDD} = \max_t |\text{DD}_t| \times 100\%$$

### 7. Calmar Ratio
$$\text{Calmar} = \frac{\text{CAGR}}{|\text{MDD}|}$$

### 8. Sharpe Degradation Index (Overfitting Metric)
$$\text{Degradation (\%)} = \frac{\text{Sharpe}_{\text{Train}} - \text{Sharpe}_{\text{Test}}}{\text{Sharpe}_{\text{Train}}} \times 100\%$$
*If Degradation $> 50\%$ or Test Sharpe falls below zero, an `Overfitting Alert` is flagged.*

---

## 🛡️ 4. Elimination of Look-Ahead & Information Leakage

In amateur backtesting code, signals generated at the close of Day $T$ are executed at the close of Day $T$, creating fatal look-ahead bias (the close price at 3:30 PM cannot be known beforehand to place an order).

**AlphaTrial Execution Proof:**
1. Signals are computed using data up to and including Bar $T$ Close:
   $$\text{Signal}_T = f(\text{OHLCV}_{\tau \le T})$$
2. The execution engine shifts the signal series strictly forward:
   $$\text{Order}_{T+1} = \text{Signal}_T$$
3. The trade is executed at **Bar $T+1$ Open**, modified by adverse slippage $\delta$:
   $$\text{Execution Price}_{\text{Buy}} = \text{Open}_{T+1} \times (1 + \delta_{\text{slippage}})$$
   $$\text{Execution Price}_{\text{Sell}} = \text{Open}_{T+1} \times (1 - \delta_{\text{slippage}})$$
4. Transaction brokerage is deducted from cash at the moment of execution:
   $$\text{Fee} = \text{Shares} \times \text{Execution Price} \times \text{Commission}\%$$

---

## 🚀 5. Quick Start & Execution Guide

### Prerequisites
Python 3.10+ with standard quantitative libraries (`pandas`, `numpy`, `scikit-learn`, `altair`, `streamlit`).

### Option A: Standalone Zero-UI CLI Verification (Pure Terminal)
Run the automated test suite to verify quantitative formulas, look-ahead bias elimination, and fee sensitivity in seconds:
```powershell
python test_alpha.py
```

### Option B: Launch Interactive Web Dashboard
Run the Streamlit application to explore interactive charts, parameter sliders, walk-forward windows, and executive tear sheets:
```powershell
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 🎯 6. Presentation Viva & Technical Defense Cheat Sheet

| Potential Judge Question | Technical Defense Answer |
| :--- | :--- |
| **"How did you prevent look-ahead bias in your backtest?"** | Signals are computed on Bar $T$ Close and strictly shifted by 1 bar (`signal.shift(1)`). All fills occur on Bar $T+1$ Open with adverse slippage added. |
| **"Why did you use Sortino and Calmar instead of just Sharpe?"** | Sharpe penalizes upward volatility equally as downward volatility. Sortino isolates downside deviation, and Calmar evaluates returns directly against peak historical loss (Drawdown). |
| **"How does transaction cost impact a high-turnover strategy?"** | In Tab 2 ("Fee Shock"), increasing commission from 0 bps to 50 bps extracts thousands in friction, demonstrating that high-frequency signals with positive raw returns turn net negative after friction. |
| **"How do you prove your ML model isn't overfitting?"** | The Scikit-Learn Random Forest is trained strictly on In-Sample (first 70%) historical features. Feature computation only uses lagged technicals ($t-1$), and testing is evaluated strictly on the remaining 30% unseen data. |
| **"What are the failure modes of moving average crossovers?"** | In range-bound or sideways choppy regimes, moving averages repeatedly cross back and forth ("whipsaw"), inducing excessive turnover and consecutive loss-making trades. |

---
*Developed with mathematical rigor for BSAC QuantActive 2026.*
