"""
AlphaTrial Data Ingestion & Hygiene Engine
Complies with BSAC (MNNIT Allahabad) Track Guidelines:
- Section 3: Data & Validation (Explicit preprocessing, sorting, handling missing values)
- Section 7: Prevention of Look-Ahead & Leakage
- Provides CSV ingestion, automated column mapping, and multi-regime historical datasets.
"""

import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Tuple, Dict, Any, Union

def standardize_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Standardizes column names to title case: Date, Open, High, Low, Close, Volume."""
    df = df.copy()
    col_map = {}
    for c in df.columns:
        norm = str(c).strip().capitalize()
        col_map[c] = norm
    df.rename(columns=col_map, inplace=True)
    return df

def load_stock_csv(filepath_or_buffer: Union[str, Any]) -> pd.DataFrame:
    """
    Ingests and cleans historical stock CSV time series.
    
    Validation & Assumptions:
    1. CSV must contain a valid Date column and OHLC price columns.
    2. Chronological sorting in ascending order is strictly enforced.
    3. Handles missing values via forward-filling; drops unrecoverable nulls.
    4. Validates price positivity (eliminates zeros/negative quotes).
    """
    df = pd.read_csv(filepath_or_buffer)
    df = standardize_columns(df)
    
    if 'Date' not in df.columns:
        raise ValueError("Dataset Error: Mandatory column 'Date' is missing.")
        
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df = df.dropna(subset=['Date'])
    df = df.sort_values('Date').reset_index(drop=True)
    df.set_index('Date', inplace=True)
    
    required_cols = ['Open', 'High', 'Low', 'Close']
    for col in required_cols:
        if col not in df.columns:
            # Fallback if only 'Close' is provided: derive O, H, L from Close
            if 'Close' in df.columns and col in ['Open', 'High', 'Low']:
                df[col] = df['Close']
            else:
                raise ValueError(f"Dataset Error: Mandatory column '{col}' is missing.")
                
    if 'Volume' not in df.columns:
        df['Volume'] = 1_000_000 # Standard nominal volume
        
    for col in required_cols + ['Volume']:
        df[col] = pd.to_numeric(df[col], errors='coerce')
        
    # Data hygiene: remove non-positive prices
    for col in required_cols:
        df[col] = df[col].replace(0, np.nan).ffill().bfill()
        if (df[col] <= 0).any():
            raise ValueError(f"Dataset Error: Non-positive price encountered in column '{col}'.")
            
    # Re-verify High >= Low and High >= max(Open, Close)
    df['High'] = np.maximum(df['High'], np.maximum(df['Open'], df['Close']))
    df['Low'] = np.minimum(df['Low'], np.minimum(df['Open'], df['Close']))
    
    return df

def generate_multi_regime_data(
    symbol: str = "SYNTH_TRIAL",
    start_date: str = "2021-01-01",
    num_days: int = 1000,
    initial_price: float = 150.0,
    seed: int = 42
) -> pd.DataFrame:
    """
    Generates reproducible multi-regime financial price series with:
    - Regime 1 (0 to 350 days): Strong Bull Market (positive drift, moderate vol)
    - Regime 2 (350 to 500 days): Severe Liquidity Crash (negative drift, high vol)
    - Regime 3 (500 to 750 days): Choppy / Sideways Mean-Reversion (zero drift, low vol)
    - Regime 4 (750 to 1000 days): Steady Recovery & Expansion
    
    Useful for stress-testing rule-based strategies across distinct market environments.
    """
    np.random.seed(seed)
    date_range = pd.date_range(start=start_date, periods=num_days, freq='B')
    
    daily_returns = np.zeros(num_days)
    # Regime 1: Bull Market (+18% annualized drift, 14% vol)
    daily_returns[0:350] = np.random.normal(0.0007, 0.009, 350)
    # Regime 2: Crash (-45% annualized drawdown, 30% vol)
    daily_returns[350:500] = np.random.normal(-0.0030, 0.022, 150)
    # Regime 3: Sideways / Chop (near zero drift, 12% vol)
    daily_returns[500:750] = np.random.normal(0.0001, 0.008, 250)
    # Regime 4: Recovery (+14% annualized, 15% vol)
    daily_returns[750:num_days] = np.random.normal(0.0005, 0.010, num_days - 750)
    
    log_cum_ret = np.cumsum(daily_returns)
    price_series = initial_price * np.exp(log_cum_ret)
    
    high = price_series * (1.0 + np.abs(np.random.normal(0.004, 0.003, num_days)))
    low = price_series * (1.0 - np.abs(np.random.normal(0.004, 0.003, num_days)))
    open_prices = low + (high - low) * np.random.uniform(0.2, 0.8, num_days)
    volume = np.random.lognormal(mean=14.5, sigma=0.4, size=num_days).astype(int)
    
    df = pd.DataFrame({
        'Date': date_range,
        'Open': np.round(open_prices, 2),
        'High': np.round(high, 2),
        'Low': np.round(low, 2),
        'Close': np.round(price_series, 2),
        'Volume': volume
    })
    df.set_index('Date', inplace=True)
    return df

def save_sample_datasets(base_dir: str):
    """Generates standard sample CSV files for instant testing in the platform."""
    sample_dir = os.path.join(base_dir, "data", "sample_data")
    os.makedirs(sample_dir, exist_ok=True)
    
    configs = [
        ("NIFTY_50_INDEX", "2020-01-01", 1100, 12000.0, 101),
        ("RELIANCE_EQ", "2020-01-01", 1100, 1500.0, 202),
        ("AAPL_TECH", "2020-01-01", 1100, 100.0, 303)
    ]
    
    for symbol, start_d, days, price, seed in configs:
        file_path = os.path.join(sample_dir, f"{symbol}.csv")
        if not os.path.exists(file_path):
            df = generate_multi_regime_data(symbol, start_d, days, price, seed)
            df.to_csv(file_path)
