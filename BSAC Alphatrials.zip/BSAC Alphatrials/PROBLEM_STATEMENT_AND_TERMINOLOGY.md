# AlphaTrial: Problem Statement, Financial Terminology & Model Strategy Guide
**QUANTACTIVE — CODE CONFLUX**  
*Organized by Business Strategy and Analytics Club (BSAC), MNNIT Allahabad*  
**Track:** PS 01 — Build, Backtest & Validate a Trading Strategy

---

## 📑 Table of Contents
1. [Core Problem Statement & Real-World Motivation](#1-core-problem-statement--real-world-motivation)
2. [Why 90% of Retail Trading Strategies Fail](#2-why-90-of-retail-trading-strategies-fail)
3. [Comprehensive Glossary of Financial & Quantitative Terms](#3-comprehensive-glossary-of-financial--quantitative-terms)
4. [Trading Rules & Model Mechanisms](#4-trading-rules--model-mechanisms)
5. [The Step-by-Step Model Building Strategy (BSAC Framework)](#5-the-step-by-step-model-building-strategy-bsac-framework)
6. [Judging Checklist & Viva Defense Strategy](#6-judging-checklist--viva-defense-strategy)

---

## 1. Core Problem Statement & Real-World Motivation

### The Challenge
Traders frequently design trading strategies using technical indicators, price trends, and visual chart patterns. A strategy may look exceptionally profitable over a specific 1-year historical chart. However, when deployed in live markets:
- Changing market regimes (e.g., transition from a bull market to a choppy or crashing market) turn gains into steep drawdowns.
- Real-world execution friction (brokerage commissions, exchange transaction taxes, adverse slippage) quietly eats away all apparent profits.
- Accidental inclusion of future price information ("look-ahead bias") creates an illusion of predictive power that cannot exist in reality.
- Tuning too many parameters on historical noise creates severe "overfitting," causing the strategy to collapse on unseen future data.

### The Objective of AlphaTrial
Build an institutional-grade, rule-based quantitative trading backtesting and strategy validation engine that:
1. Ingests historical daily/granular stock CSV data with strict data validation.
2. Implements rule-based strategies (Moving Average Crossovers, RSI Mean-Reversion, Rate-of-Change Momentum) and Machine Learning regime classifiers.
3. Simulates realistic trade executions with cash constraints, brokerage fees, and adverse price slippage.
4. Strictly eliminates look-ahead bias by executing signals generated on Bar $T$ Close at Bar $T+1$ Open.
5. Calculates rigorous risk-adjusted performance metrics (CAGR, Annualized Volatility, Sharpe, Sortino, Calmar, Max Drawdown, Win Rate, Profit Factor).
6. Compares performance against a passive Buy-and-Hold benchmark.
7. Validates models using In-Sample vs. Out-of-Sample evaluation, Sharpe Degradation Index, Walk-Forward rolling windows, and market regime breakdowns.

---

## 2. Why 90% of Retail Trading Strategies Fail

| Pitfall | What Amateurs Do | What AlphaTrial Does Differently |
| :--- | :--- | :--- |
| **Look-Ahead Bias** | Compute a signal at 3:30 PM Close and assume they executed at that exact same 3:30 PM Close price. | Signals computed at Bar $T$ Close are strictly shifted forward and filled at **Bar $T+1$ Open**. |
| **Zero Friction Fantasy** | Assume trades execute at zero cost, making high-turnover scalping look artificially lucrative. | Deducts **brokerage commission** (e.g., 10 bps) and **adverse slippage** (e.g., 5 bps) on every entry and exit. |
| **Overfitting (Curve Fitting)** | Test 500 combinations of indicator parameters until one fits historical data, mistaking noise for alpha. | Chronological **70/30 In-Sample vs. Out-of-Sample split**, triggering an **Overfitting Alert** if Sharpe drops $>50\%$. |
| **Regime Blindness** | Test solely during a 2-year bull market and claim the strategy is foolproof. | Tests across **multi-regime scenarios** (Bull Trend, Crash / Bear Drop, Choppy Consolidation). |
| **Unconstrained Leverage** | Assume infinite money or ignore cash balance when buying assets. | Strictly tracks portfolio cash; trade size is constrained by available liquidation balance. |

---

## 3. Comprehensive Glossary of Financial & Quantitative Terms

### A. Execution & Backtesting Terms
- **Backtesting:** Simulating a trading strategy using historical data to discover how it would have performed in the past.
- **Bar / Candle:** A single discrete time unit (e.g., 1 day) containing Open, High, Low, Close (OHLC) prices and Volume.
- **Look-Ahead Bias (Information Leakage):** Using information in your trading decision that was not available at the time the decision had to be made. (Example: Deciding to buy at morning Open based on the evening Close of the same day).
- **Execution Price:** The actual price at which an order gets filled. In reality, it differs from the theoretical signal price due to slippage.
- **Slippage:** The difference between the expected fill price and the executed fill price caused by market movement or bid-ask spread. For BUY orders, price slips upwards (+); for SELL orders, price slips downwards (-).
- **Basis Points (bps):** One basis point is equal to $\frac{1}{100}$ of $1\%$ ($0.01\%$, or $0.0001$).  
  *Example:* $10\text{ bps} = 0.10\%$. On a $\$100,000$ trade, $10\text{ bps}$ fee is $\$100$.
- **Mark-to-Market (MTM):** Valuing portfolio holdings at current market prices at the end of each trading day ($\text{Cash} + \text{Shares} \times \text{Close Price}$).
- **Cash Constraint:** An execution boundary ensuring orders cannot exceed available liquidity. If cash is $\$10,000$, the system cannot buy $\$15,000$ worth of stock without margin.
- **Buy-and-Hold Benchmark:** A passive investment strategy where capital is invested into the asset on Day 1 and held continuously until the end, ignoring all signals. It serves as the baseline to beat.

---

### B. Performance & Return Metrics
- **Cumulative Return ($R_{\text{cum}}$):** The total percentage increase in portfolio value over the entire backtest window:
  $$R_{\text{cum}} = \frac{V_{\text{final}} - V_{\text{initial}}}{V_{\text{initial}}} \times 100\%$$
- **Compound Annual Growth Rate (CAGR):** The smoothed annual geometric return rate over multiple years, normalizing tests of differing durations:
  $$\text{CAGR} = \left(\frac{V_{\text{final}}}{V_{\text{initial}}}\right)^{\frac{252}{N_{\text{trading\_days}}}} - 1$$
- **Annualized Volatility ($\sigma_{\text{ann}}$):** The standard deviation of daily percentage returns scaled to an annual basis using 252 trading days:
  $$\sigma_{\text{ann}} = \sigma(R_{\text{daily}}) \times \sqrt{252}$$
  *Intuition:* Measures how wildly portfolio value swings up and down. Lower volatility means smoother returns.

---

### C. Risk-Adjusted Ratios (Brownie Point: Beyond Total Profit)
- **Risk-Free Rate ($R_f$):** The theoretical rate of return of an investment with zero risk (e.g., government treasury bills, typically assumed at $5.0\%$ or $0.05$ annually).
- **Sharpe Ratio:** The gold standard metric for risk-adjusted return. Measures return earned per unit of total risk:
  $$\text{Sharpe} = \frac{\mu(R_{\text{daily}} - R_{f,\text{daily}})}{\sigma(R_{\text{daily}})} \times \sqrt{252}$$
  - $\text{Sharpe} < 1.0$: Sub-optimal risk compensation.
  - $\text{Sharpe} \ge 1.0$: Good institutional quality.
  - $\text{Sharpe} \ge 2.0$: Outstanding performance.
- **Sortino Ratio:** An enhancement over Sharpe. Sharpe penalizes upside volatility (sudden big gains) as "risk." Sortino penalizes *only* downside volatility (losses):
  $$\text{Sortino} = \frac{\mu(R_{\text{daily}} - R_{f,\text{daily}})}{\sigma\left(\min(R_{\text{daily}} - R_{f,\text{daily}}, 0)\right)} \times \sqrt{252}$$
- **High Watermark (Peak Value):** The highest historical portfolio valuation achieved up to time $t$.
- **Drawdown (DD):** The percentage drop in portfolio value from its historical high watermark:
  $$\text{DD}_t = \frac{V_t - \text{Peak}_t}{\text{Peak}_t}$$
- **Maximum Drawdown (MDD):** The largest peak-to-trough percentage decline experienced during the entire backtest:
  $$\text{MDD} = \max_t |\text{DD}_t| \times 100\%$$
  *Intuition:* Measures the worst-case pain an investor would suffer before recovering.
- **Calmar Ratio:** Compares annualized return (CAGR) directly against Maximum Drawdown:
  $$\text{Calmar} = \frac{\text{CAGR}}{|\text{MDD}|}$$
  *Intuition:* Answers "How much return am I generating for every unit of catastrophic loss potential?"
- **Win Rate (%):** The proportion of completed round-trip trades (entry to liquidation) that yielded a positive net profit:
  $$\text{Win Rate} = \frac{\text{Count of Winning Trades}}{\text{Total Completed Trades}} \times 100\%$$
- **Profit Factor:** The ratio of gross profits to gross losses across all closed trades:
  $$\text{Profit Factor} = \frac{\sum \text{Gross Profit}}{\sum |\text{Gross Loss}|}$$
  *A profit factor $> 1.5$ indicates strong statistical edge.*

---

### D. Validation, Overfitting & Regime Terms
- **In-Sample (Training Data):** The historical period used to formulate rules and optimize parameters (first 70% of chronological timeline).
- **Out-of-Sample (Unseen Testing Data):** The remaining historical period (final 30%) strictly withheld during model building. Used to test if the strategy actually works on new data.
- **Overfitting (Data Snooping Bias):** When a model learns random historical noise rather than genuine market dynamics. It produces sky-high returns on training data but collapses on testing data.
- **Sharpe Degradation Index:** The percentage decline in Sharpe Ratio between training data and testing data:
  $$\text{Degradation (\%)} = \frac{\text{Sharpe}_{\text{Train}} - \text{Sharpe}_{\text{Test}}}{\text{Sharpe}_{\text{Train}}} \times 100\%$$
  *If Degradation $> 50\%$, an Overfitting Warning is raised.*
- **Walk-Forward Analysis (Rolling Window):** A rolling validation method where a training window (e.g., 252 days) steps forward across time, followed by an out-of-sample forward evaluation step (e.g., 63 days). Demonstrates whether parameter effectiveness persists across changing market cycles.
- **Market Regimes:** Distinct macroeconomic conditions:
  1. *Bull Trend:* Persistent upward price momentum (Price $> 200\text{ SMA}$).
  2. *Bear Crash:* Severe downward selling pressure (Price $< 200\text{ SMA}$).
  3. *Sideways / Chop:* Range-bound oscillation without directional conviction. Moving average strategies suffer whipsaw losses here.
- **Fee Sensitivity Shock (Brownie Point):** Stress-testing a strategy by systematically scaling friction from 0 bps up to 50 bps to reveal how quickly transaction costs consume profits.

---

## 4. Trading Rules & Model Mechanisms

### 1. Moving Average Crossover (Trend Following)
- **Concept:** Calculates two moving averages of closing prices: a Fast MA (e.g., 20 days) and a Slow MA (e.g., 50 days).
- **Rule:**
  - *Golden Cross:* When Fast MA crosses above Slow MA $\rightarrow$ Enter Long (Signal = 1).
  - *Death Cross:* When Fast MA crosses below Slow MA $\rightarrow$ Exit to Cash (Signal = 0).
- **Strength:** Captures major multi-month rallies; avoids deep bear market crashes.
- **Weakness:** Generates "whipsaw" losses in sideways choppy markets.

### 2. Relative Strength Index (RSI Mean-Reversion)
- **Concept:** Measures the velocity and magnitude of directional price movements on a scale of 0 to 100 using Wilder's 14-period smoothed averages of gains vs. losses.
- **Rule:**
  - *Oversold Trigger:* When RSI drops $\le 30 \rightarrow$ Asset is undervalued; Enter Long.
  - *Overbought Trigger:* When RSI rises $\ge 70 \rightarrow$ Asset is overextended; Exit to Cash.
- **Strength:** Excellent in range-bound and consolidating markets.
- **Weakness:** Prematurely exits or takes losing counter-trend positions during massive runaway bull or bear trends.

### 3. Momentum / Rate of Change (ROC)
- **Concept:** Measures percentage price displacement over an $N$-day lookback window:
  $$\text{ROC}_t = \frac{\text{Close}_t - \text{Close}_{t-N}}{\text{Close}_{t-N}} \times 100\%$$
- **Rule:**
  - Enter Long when $\text{ROC} > \text{threshold}$ (e.g., $+1.0\%$).
  - Exit to Cash when momentum weakens ($\text{ROC} \le 0.0\%$).
- **Strength:** High agility; rapid entry into sudden explosive breakouts.
- **Weakness:** Higher trade turnover, generating elevated brokerage and slippage costs.

### 4. Machine Learning Regime Classifier (Random Forest)
- **Concept:** An ensemble decision tree model trained on lagged historical features:
  - 1-day, 5-day, 10-day, 20-day percentage returns
  - 14-day normalized RSI
  - 20-day rolling return volatility
  - Volume anomaly ratio ($\frac{\text{Volume}}{\text{20d Rolling Mean}}$)
- **Rule:** Predicts probability of positive forward return. If $\text{Probability} \ge \text{Confidence Cutoff}$ (e.g., $0.52$), output Long (1), else Flat (0).
- **Anti-Leakage Safeguard:** The model is trained *strictly* on In-Sample historical data with target shifts aligned to prevent future leakage.

---

## 5. The Step-by-Step Model Building Strategy (BSAC Framework)

To build models that directly satisfy the BSAC judging rubrics, follow this 6-stage quantitative pipeline:

```
┌─────────────────────────────────────────────────────────────┐
│ 1. DATA INGESTION & HYGIENE                                  │
│ - CSV Parsing: OHLCV format validation                      │
│ - Chronological sorting (ascending order)                   │
│ - Missing data handling (ffill) & zero price rejection       │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 2. STRATEGY SIGNAL GENERATION                                │
│ - Mathematical rule calculation on Bar T close               │
│ - Backward-looking features only (no future data)            │
│ - Output signals: 1 (Long) or 0 (Cash)                      │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 3. STRICT EXECUTION MECHANICS (LOOK-AHEAD ELIMINATION)       │
│ - Signal strictly shifted by 1 bar: signal.shift(1)         │
│ - Trade executes at Bar T+1 Open                            │
│ - Deduct Commission % (10 bps) + Adverse Slippage % (5 bps) │
│ - Portfolio Cash constraints enforced                       │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 4. PERFORMANCE & RISK ATTRIBUTION                            │
│ - Cumulative Return & CAGR                                  │
│ - Annualized Volatility & Sharpe Ratio (Rf = 5%)            │
│ - Sortino Ratio (downside risk) & Calmar Ratio              │
│ - High-Watermark Maximum Drawdown & Win Rate                │
│ - Side-by-side Buy-and-Hold Benchmark comparison            │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 5. RIGOROUS VALIDATION & OVERFITTING CHECKS                 │
│ - In-Sample (70%) vs Out-of-Sample (30%) split              │
│ - Calculate Sharpe Degradation Index                        │
│ - Walk-Forward Rolling Analysis (W1 through W10)            │
│ - Market Regime Decomposition (Bull, Bear, Sideways)        │
│ - Fee Sensitivity Shock (0 to 50 bps)                       │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│ 6. REPORTING & DEFENSE PREPARATION                           │
│ - Feature status transparency [Implemented] badges          │
│ - Trade audit log CSV generation                            │
│ - Strengths, Weaknesses & Failure Modes documentation        │
│ - Interactive Web Dashboard & Zero-UI CLI test suite        │
└─────────────────────────────────────────────────────────────┘
```

---

## 6. Judging Checklist & Viva Defense Strategy

When defending the project before the BSAC judges, utilize these concise quantitative answers:

| Judging Area | Anticipated Judge Question | Winning Defense Response |
| :--- | :--- | :--- |
| **Section 1: Problem Understanding** | *"Why is backtesting often misleading in trading?"* | Because simple backtests assume frictionless execution, leak future prices, and test exclusively on past data where parameters were already fitted. AlphaTrial eliminates all three pitfalls. |
| **Section 2: Quantitative Correctness** | *"How did you annualize Sharpe and handle risk-free rate?"* | We annualized using $\sqrt{252}$ trading days with daily compounding of a 5.0% annual risk-free rate: $R_{f,\text{daily}} = (1 + 0.05)^{\frac{1}{252}} - 1$. |
| **Section 3: Data & Validation** | *"How do you prove look-ahead bias is absent?"* | Signals calculated on Day $T$ close are shifted using `signal.shift(1)` so orders execute strictly on Day $T+1$ open at `Open * (1 + slippage)`. Day $T$ execution never happens. |
| **Section 5: Innovation & Results** | *"What are the Brownie points demonstrated?"* | 1) Fee Sensitivity Shock showing how rising friction from 0 to 50 bps erodes alpha; 2) Sharpe Degradation Index detecting overfitting between 70% train and 30% test data; 3) Regime decomposition separating Bull, Bear, and Chop performance. |
| **Section 7: Specific AlphaTrial Checks** | *"What is the main failure mode of Moving Average crossovers?"* | During Sideways / Chop regimes, the fast and slow averages cross repeatedly without trending follow-through (whipsaw), causing continuous transaction friction losses. |

---
*Created for the AlphaTrial Project Team & Presentation Viva — Code Conflux 2026.*
