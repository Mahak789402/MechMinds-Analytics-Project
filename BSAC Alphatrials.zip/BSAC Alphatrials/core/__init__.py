"""AlphaTrial Core Engine Package"""
from .simulator import BacktestSimulator
from .metrics import compute_performance_metrics
from .optimizer import optimize_parameters
from .validator import (
    split_in_out_of_sample,
    evaluate_train_test_robustness,
    run_walk_forward_analysis,
    decompose_market_regimes,
    run_fee_sensitivity_analysis
)
