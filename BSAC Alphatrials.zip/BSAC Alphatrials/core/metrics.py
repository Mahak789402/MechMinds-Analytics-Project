"""
AlphaTrial Quantitative Metrics Engine
Implements industry-standard financial and statistical metrics.

Complies with BSAC (MNNIT Allahabad) Quantitative Correctness (Section 2):
- Annualized using 252 trading days.
- Separates upside and downside risk (Sortino vs. Sharpe).
- High-watermark Peak-to-Trough Drawdown calculation.
- Round-trip trade analytics (Win Rate, Profit Factor).
"""

import numpy as np
import pandas as pd
from typing import Dict, Any

def compute_performance_metrics(
    portfolio_series: pd.Series,
    trade_df: pd.DataFrame = None,
    risk_free_rate: float = 0.05
) -> Dict[str, Any]:
    """
    Portfolio performance aur risk metrics calculate karta hai.
    
    Inputs:
        portfolio_series: Har din ki portfolio valuation (Series)
        trade_df: Individual buy/sell trades ka DataFrame (Optional)
        risk_free_rate: Salana risk-free rate (Default: 5% = 0.05)
    """
    # Agar data bohot chota hai (<2 days) toh default zero return karo
    if len(portfolio_series) < 2:
        return {
            "Total Return (%)": 0.0,
            "CAGR (%)": 0.0,
            "Annual Volatility (%)": 0.0,
            "Sharpe Ratio": 0.0,
            "Sortino Ratio": 0.0,
            "Max Drawdown (%)": 0.0,
            "Calmar Ratio": 0.0,
            "Win Rate (%)": 0.0,
            "Profit Factor": 0.0,
            "Completed Round Trips": 0,
            "Avg Trade PnL ($)": 0.0
        }
        
    initial_val = portfolio_series.iloc[0]
    final_val = portfolio_series.iloc[-1]
    
    # -------------------------------------------------------------
    # 1. Total Cumulative Return (%)
    # Formula: (Final Value - Initial Value) / Initial Value * 100
    # -------------------------------------------------------------
    total_return_pct = ((final_val - initial_val) / initial_val) * 100.0
    
    # -------------------------------------------------------------
    # 2. Daily Returns & CAGR (Compound Annual Growth Rate %)
    # -------------------------------------------------------------
    daily_returns = portfolio_series.pct_change().dropna()
    num_years = max(len(daily_returns) / 252.0, 0.001)
    
    if final_val > 0 and initial_val > 0:
        cagr_pct = (((final_val / initial_val) ** (1.0 / num_years)) - 1.0) * 100.0
    else:
        cagr_pct = -100.0
        
    # -------------------------------------------------------------
    # 3. Annualized Volatility (%)
    # Formula: daily standard deviation * sqrt(252 trading days)
    # -------------------------------------------------------------
    daily_vol = daily_returns.std()
    ann_vol_pct = daily_vol * np.sqrt(252) * 100.0
    
    # -------------------------------------------------------------
    # 4. Sharpe Ratio (Annualized with 5% Risk-Free Rate)
    # Formula: (Daily Mean Return - Daily Rf) / Daily Volatility * sqrt(252)
    # -------------------------------------------------------------
    daily_rf = ((1.0 + risk_free_rate) ** (1.0 / 252.0)) - 1.0
    excess_returns = daily_returns - daily_rf
    
    if daily_vol > 1e-6:
        sharpe_ratio = (excess_returns.mean() / (daily_vol + 1e-9)) * np.sqrt(252)
    else:
        sharpe_ratio = 0.0
        
    # -------------------------------------------------------------
    # 5. Sortino Ratio (Downside Volatility Only)
    # Upside profit ko risk nahi manta, sirf negative returns ko penalize karta hai
    # -------------------------------------------------------------
    negative_returns = excess_returns[excess_returns < 0]
    downside_vol = negative_returns.std() if len(negative_returns) > 1 else 0.0
    
    if downside_vol > 1e-6:
        sortino_ratio = (excess_returns.mean() / (downside_vol + 1e-9)) * np.sqrt(252)
    else:
        sortino_ratio = 0.0
        
    # -------------------------------------------------------------
    # 6. Maximum Drawdown (MDD %)
    # Peak (highest portfolio value) se sabse bada drop kitna hua
    # -------------------------------------------------------------
    peak_series = portfolio_series.cummax()
    drawdown_series = (portfolio_series - peak_series) / peak_series
    max_drawdown_pct = abs(float(drawdown_series.min())) * 100.0
    
    # -------------------------------------------------------------
    # 7. Calmar Ratio
    # Formula: CAGR (%) / Max Drawdown (%)
    # -------------------------------------------------------------
    if max_drawdown_pct > 1e-4:
        calmar_ratio = cagr_pct / max_drawdown_pct
    else:
        calmar_ratio = cagr_pct
        
    # -------------------------------------------------------------
    # 8. Trade Statistics (Win Rate & Profit Factor)
    # -------------------------------------------------------------
    win_rate_pct = 0.0
    profit_factor = 0.0
    completed_trades = 0
    avg_trade_pnl = 0.0
    
    if trade_df is not None and not trade_df.empty:
        # BUY aur SELL ko pair karke complete round trips calculate karte hain
        buys = trade_df[trade_df['Action'] == 'BUY'].reset_index(drop=True)
        sells = trade_df[trade_df['Action'] == 'SELL'].reset_index(drop=True)
        completed_trades = min(len(buys), len(sells))
        
        if completed_trades > 0:
            pnls = []
            for k in range(completed_trades):
                # Total Buy Outlay = Gross + Fee
                total_buy_cost = (buys.loc[k, 'Shares'] * buys.loc[k, 'Execution_Price']) + buys.loc[k, 'Fee']
                # Net Sell Proceeds = Gross - Fee
                net_sell_revenue = (sells.loc[k, 'Shares'] * sells.loc[k, 'Execution_Price']) - sells.loc[k, 'Fee']
                trade_pnl = net_sell_revenue - total_buy_cost
                pnls.append(trade_pnl)
                
            winning_trades = [p for p in pnls if p > 0]
            losing_trades = [p for p in pnls if p <= 0]
            
            # Win Rate %
            win_rate_pct = (len(winning_trades) / completed_trades) * 100.0
            
            # Profit Factor = Total Gross Profit / Total Gross Loss
            gross_profit = sum(winning_trades)
            gross_loss = abs(sum(losing_trades))
            
            if gross_loss > 1e-4:
                profit_factor = gross_profit / gross_loss
            else:
                profit_factor = 999.0 if gross_profit > 0 else 1.0
                
            avg_trade_pnl = sum(pnls) / completed_trades

    # Final Result Dictionary
    return {
        "Total Return (%)": round(float(total_return_pct), 2),
        "CAGR (%)": round(float(cagr_pct), 2),
        "Annual Volatility (%)": round(float(ann_vol_pct), 2),
        "Sharpe Ratio": round(float(sharpe_ratio), 2),
        "Sortino Ratio": round(float(sortino_ratio), 2),
        "Max Drawdown (%)": round(float(max_drawdown_pct), 2),
        "Calmar Ratio": round(float(calmar_ratio), 2),
        "Win Rate (%)": round(float(win_rate_pct), 2),
        "Profit Factor": round(float(profit_factor), 2),
        "Completed Round Trips": completed_trades,
        "Avg Trade PnL ($)": round(float(avg_trade_pnl), 2)
    }
