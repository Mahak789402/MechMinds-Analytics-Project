"""
AlphaTrial Parameter Optimizer
Performs grid-search parameter optimization on historical In-Sample data.
Complies with BSAC Guidelines:
- Parameters are tuned strictly on training data to prevent look-ahead contamination.
- Generates parameter performance rankings across Sharpe, Return, and Drawdown.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Type
from strategies.base_strategy import BaseStrategy
from strategies.moving_average import MovingAverageCrossover
from strategies.rsi_strategy import RSIStrategy
from strategies.momentum_strategy import MomentumStrategy
from .simulator import BacktestSimulator
from .metrics import compute_performance_metrics

def optimize_parameters(
    strategy_type: str,
    df_train: pd.DataFrame,
    param_grid: Dict[str, List[Any]],
    objective_metric: str = "Sharpe Ratio",
    initial_capital: float = 100_000.0,
    commission_pct: float = 0.0010,
    slippage_pct: float = 0.0005
) -> Dict[str, Any]:
    """
    Evaluates combinations in param_grid strictly over df_train.
    
    Returns:
        best_params: Dict of optimal parameter values.
        best_metrics: Dict of metrics attained by optimal params.
        results_table: pd.DataFrame ranking all candidate combinations.
    """
    simulator = BacktestSimulator(
        initial_capital=initial_capital,
        commission_pct=commission_pct,
        slippage_pct=slippage_pct
    )
    
    records = []
    
    if strategy_type == "MovingAverageCrossover":
        fast_list = param_grid.get("fast_window", [10, 20, 30])
        slow_list = param_grid.get("slow_window", [50, 100, 200])
        ma_types = param_grid.get("ma_type", ["SMA"])
        
        for ma_type in ma_types:
            for fast in fast_list:
                for slow in slow_list:
                    if fast >= slow:
                        continue
                    strat = MovingAverageCrossover(fast_window=fast, slow_window=slow, ma_type=ma_type)
                    sig = strat.generate_signals(df_train)
                    eq, trades, _ = simulator.run_backtest(df_train, sig)
                    m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                    
                    records.append({
                        "fast_window": fast,
                        "slow_window": slow,
                        "ma_type": ma_type,
                        "Sharpe Ratio": m["Sharpe Ratio"],
                        "Total Return (%)": m["Total Return (%)"],
                        "Max Drawdown (%)": m["Max Drawdown (%)"],
                        "Calmar Ratio": m["Calmar Ratio"],
                        "Win Rate (%)": m["Win Rate (%)"],
                        "Trades": m["Completed Round Trips"]
                    })
                    
    elif strategy_type == "RSIStrategy":
        period_list = param_grid.get("period", [10, 14, 21])
        oversold_list = param_grid.get("oversold", [25, 30, 35])
        overbought_list = param_grid.get("overbought", [65, 70, 75])
        
        for p in period_list:
            for os_val in oversold_list:
                for ob_val in overbought_list:
                    strat = RSIStrategy(period=p, oversold=os_val, overbought=ob_val)
                    sig = strat.generate_signals(df_train)
                    eq, trades, _ = simulator.run_backtest(df_train, sig)
                    m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                    
                    records.append({
                        "period": p,
                        "oversold": os_val,
                        "overbought": ob_val,
                        "Sharpe Ratio": m["Sharpe Ratio"],
                        "Total Return (%)": m["Total Return (%)"],
                        "Max Drawdown (%)": m["Max Drawdown (%)"],
                        "Calmar Ratio": m["Calmar Ratio"],
                        "Win Rate (%)": m["Win Rate (%)"],
                        "Trades": m["Completed Round Trips"]
                    })
                    
    elif strategy_type == "MomentumStrategy":
        lookback_list = param_grid.get("lookback", [10, 20, 40, 60])
        thresh_list = param_grid.get("entry_threshold", [0.0, 1.0, 2.0, 3.0])
        
        for lb in lookback_list:
            for thr in thresh_list:
                strat = MomentumStrategy(lookback=lb, entry_threshold=thr)
                sig = strat.generate_signals(df_train)
                eq, trades, _ = simulator.run_backtest(df_train, sig)
                m = compute_performance_metrics(eq['Portfolio_Value'], trades)
                
                records.append({
                    "lookback": lb,
                    "entry_threshold": thr,
                    "Sharpe Ratio": m["Sharpe Ratio"],
                    "Total Return (%)": m["Total Return (%)"],
                    "Max Drawdown (%)": m["Max Drawdown (%)"],
                    "Calmar Ratio": m["Calmar Ratio"],
                    "Win Rate (%)": m["Win Rate (%)"],
                    "Trades": m["Completed Round Trips"]
                })
                
    if not records:
        return {"best_params": {}, "results_table": pd.DataFrame()}
        
    results_df = pd.DataFrame(records)
    # Sort by objective metric descending
    results_df = results_df.sort_values(by=objective_metric, ascending=False).reset_index(drop=True)
    
    best_row = results_df.iloc[0].to_dict()
    
    return {
        "best_row": best_row,
        "results_table": results_df
    }
