"""
AlphaTrial Quantitative Backtesting Simulator
Executes rule-based strategies under realistic market conditions.

Directly addresses BSAC MNNIT Allahabad Track Checks:
1. Strict Elimination of Look-Ahead Bias:
   - Signals generated at Bar T Close are strictly shifted forward and executed at Bar T+1 Open.
2. Realistic Friction:
   - Brokerage/commission deducted on every entry and exit.
   - Slippage modeled as adverse execution price delta (+ for buy, - for sell).
3. Cash & Portfolio Constraints:
   - Trades cannot exceed available cash balance.
   - Tracks cash, share holdings, and marked-to-market portfolio value.
   - Comprehensive trade-by-trade audit log generated.
"""

import pandas as pd
import numpy as np
from typing import Tuple, Dict, Any, List

class BacktestSimulator:
    def __init__(
        self,
        initial_capital: float = 100_000.0,
        commission_pct: float = 0.0010,  # 0.10% (10 bps) typical brokerage
        slippage_pct: float = 0.0005     # 0.05% (5 bps) typical market impact
    ):
        self.initial_capital = float(initial_capital)
        self.commission_pct = float(commission_pct)
        self.slippage_pct = float(slippage_pct)

    def run_backtest(
        self,
        df: pd.DataFrame,
        signals: pd.Series
    ) -> Tuple[pd.DataFrame, pd.DataFrame, Dict[str, Any]]:
        """
        Executes backtest adhering to strict execution protocols.
        
        Parameters:
            df: Historical OHLCV data.
            signals: Target position series [1 = Long, 0 = Flat], aligned with df.index.
            
        Returns:
            equity_df: Daily portfolio equity timeseries & benchmark comparison.
            trade_df: Detailed trade execution log.
            summary: Execution friction and turnover summary.
        """
        # Ensure perfect index alignment
        common_idx = df.index.intersection(signals.index)
        data = df.loc[common_idx].copy()
        raw_signals = signals.loc[common_idx].fillna(0).astype(int)
        
        # 1. Elimination of Look-Ahead Bias:
        # A signal computed on Bar T close can only be acted upon starting Bar T+1 Open!
        exec_signals = raw_signals.shift(1).fillna(0).astype(int)
        
        cash = self.initial_capital
        shares = 0
        current_state = 0 # 0 = Flat, 1 = Long
        
        portfolio_values = []
        cash_history = []
        shares_history = []
        
        trade_log: List[Dict[str, Any]] = []
        trade_id = 1
        
        total_commission_paid = 0.0
        total_slippage_cost = 0.0
        
        open_prices = data['Open'].values
        close_prices = data['Close'].values
        dates = data.index
        
        for i in range(len(data)):
            target_pos = exec_signals.iloc[i]
            open_p = open_prices[i]
            close_p = close_prices[i]
            curr_date = dates[i]
            
            # Action: Enter Long
            if target_pos == 1 and current_state == 0:
                # Adverse slippage on BUY: price increases
                exec_price = open_p * (1.0 + self.slippage_pct)
                slippage_delta = exec_price - open_p
                
                # Maximum affordable shares subject to cash and fee
                affordable_shares = int(cash // (exec_price * (1.0 + self.commission_pct)))
                
                if affordable_shares > 0:
                    gross_cost = affordable_shares * exec_price
                    fee = gross_cost * self.commission_pct
                    total_outlay = gross_cost + fee
                    
                    cash -= total_outlay
                    shares = affordable_shares
                    current_state = 1
                    
                    slippage_loss = shares * slippage_delta
                    total_commission_paid += fee
                    total_slippage_cost += slippage_loss
                    
                    trade_log.append({
                        'Trade_ID': trade_id,
                        'Date': curr_date,
                        'Action': 'BUY',
                        'Open_Price': round(open_p, 2),
                        'Execution_Price': round(exec_price, 2),
                        'Shares': shares,
                        'Gross_Value': round(gross_cost, 2),
                        'Fee': round(fee, 2),
                        'Slippage_Cost': round(slippage_loss, 2),
                        'Cash_Remaining': round(cash, 2)
                    })
                    trade_id += 1
            
            # Action: Exit to Cash (Liquidate)
            elif target_pos == 0 and current_state == 1:
                # Adverse slippage on SELL: price decreases
                exec_price = open_p * (1.0 - self.slippage_pct)
                slippage_delta = open_p - exec_price
                
                gross_proceeds = shares * exec_price
                fee = gross_proceeds * self.commission_pct
                net_proceeds = gross_proceeds - fee
                
                slippage_loss = shares * slippage_delta
                total_commission_paid += fee
                total_slippage_cost += slippage_loss
                
                cash += net_proceeds
                
                trade_log.append({
                    'Trade_ID': trade_id,
                    'Date': curr_date,
                    'Action': 'SELL',
                    'Open_Price': round(open_p, 2),
                    'Execution_Price': round(exec_price, 2),
                    'Shares': shares,
                    'Gross_Value': round(gross_proceeds, 2),
                    'Fee': round(fee, 2),
                    'Slippage_Cost': round(slippage_loss, 2),
                    'Cash_Remaining': round(cash, 2)
                })
                trade_id += 1
                shares = 0
                current_state = 0
                
            # Marked-to-market end of day value
            mtm_value = cash + (shares * close_p)
            portfolio_values.append(mtm_value)
            cash_history.append(cash)
            shares_history.append(shares)
            
        equity_df = pd.DataFrame(index=data.index)
        equity_df['Portfolio_Value'] = portfolio_values
        equity_df['Cash'] = cash_history
        equity_df['Shares'] = shares_history
        equity_df['Position'] = raw_signals.values
        equity_df['Daily_Return'] = equity_df['Portfolio_Value'].pct_change().fillna(0.0)
        
        # Benchmark calculation: Passive Buy and Hold from Bar 1 Open
        first_open = open_prices[0]
        bnh_shares = int(self.initial_capital // (first_open * (1.0 + self.commission_pct)))
        bnh_fee = bnh_shares * first_open * self.commission_pct
        bnh_cash = self.initial_capital - (bnh_shares * first_open) - bnh_fee
        
        equity_df['Benchmark_Value'] = bnh_cash + (bnh_shares * close_prices)
        equity_df['Benchmark_Daily_Return'] = equity_df['Benchmark_Value'].pct_change().fillna(0.0)
        
        # High watermark & Drawdown
        equity_df['Peak_Value'] = equity_df['Portfolio_Value'].cummax()
        equity_df['Drawdown'] = (equity_df['Portfolio_Value'] - equity_df['Peak_Value']) / equity_df['Peak_Value']
        
        equity_df['Benchmark_Peak'] = equity_df['Benchmark_Value'].cummax()
        equity_df['Benchmark_Drawdown'] = (equity_df['Benchmark_Value'] - equity_df['Benchmark_Peak']) / equity_df['Benchmark_Peak']
        
        trade_df = pd.DataFrame(trade_log) if trade_log else pd.DataFrame(
            columns=['Trade_ID', 'Date', 'Action', 'Open_Price', 'Execution_Price', 'Shares', 'Gross_Value', 'Fee', 'Slippage_Cost', 'Cash_Remaining']
        )
        
        summary = {
            'Initial_Capital': self.initial_capital,
            'Ending_Capital': round(portfolio_values[-1], 2),
            'Total_Trades': len(trade_df),
            'Total_Commission_Paid': round(total_commission_paid, 2),
            'Total_Slippage_Cost': round(total_slippage_cost, 2),
            'Total_Friction': round(total_commission_paid + total_slippage_cost, 2),
            'Commission_Pct': self.commission_pct,
            'Slippage_Pct': self.slippage_pct
        }
        
        return equity_df, trade_df, summary
