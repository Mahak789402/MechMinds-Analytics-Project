"""
AlphaTrial: Institutional Quantitative Trading Strategy Platform
Built for BSAC QuantActive — Code Conflux 2026 (MNNIT Allahabad)
Track: PS 01 - AlphaTrial: Build, Backtest & Validate a Trading Strategy
"""

import os
import sys
import pandas as pd
import numpy as np
import streamlit as st

# Setup path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from data.data_loader import load_stock_csv, generate_multi_regime_data, save_sample_datasets
from strategies.moving_average import MovingAverageCrossover
from strategies.rsi_strategy import RSIStrategy
from strategies.momentum_strategy import MomentumStrategy
from strategies.ml_strategy import MLRegimeStrategy
from core.simulator import BacktestSimulator
from core.metrics import compute_performance_metrics
from core.validator import (
    evaluate_train_test_robustness,
    run_walk_forward_analysis,
    decompose_market_regimes,
    run_fee_sensitivity_analysis
)
from core.optimizer import optimize_parameters
from ui.charts import (
    create_equity_chart,
    create_drawdown_chart,
    create_fee_shock_chart,
    create_walk_forward_chart
)
from ui.report_exporter import generate_markdown_audit_report

# Page Config
st.set_page_config(
    page_title="AlphaTrial | Quant Strategy Platform",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom Styling for Institutional Dark FinTech Aesthetic
st.markdown("""
<style>
    .main {
        background-color: #0b0f19;
    }
    .metric-card {
        background: linear-gradient(135deg, #131c2e 0%, #17243c 100%);
        padding: 16px 20px;
        border-radius: 10px;
        border: 1px solid #1e2e4a;
        margin-bottom: 12px;
    }
    .badge-implemented {
        background-color: #00E676;
        color: #000;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 11px;
    }
    .badge-brownie {
        background-color: #FFD600;
        color: #000;
        padding: 3px 8px;
        border-radius: 4px;
        font-weight: bold;
        font-size: 11px;
    }
    .alert-box {
        padding: 14px 18px;
        border-radius: 8px;
        margin-top: 10px;
        margin-bottom: 15px;
    }
</style>
""", unsafe_allow_html=True)

# Ensure sample data exists
base_dir = os.path.abspath(os.path.dirname(__file__))
save_sample_datasets(base_dir)

# Header
st.title("📈 AlphaTrial: Quantitative Strategy Platform")
st.markdown(
    """**QUANTACTIVE — CODE CONFLUX** | Organized by *Business Strategy & Analytics Club (BSAC), MNNIT Allahabad*  
    *Rigorous rule-based strategy backtesting, execution friction modeling, and walk-forward overfitting validation.*
    """
)

# Feature Badges (BSAC Section 8 Compliance)
st.markdown(
    """
    <span class="badge-implemented">Basic Functionalities: [Implemented]</span>
    <span class="badge-implemented">Advanced Quant: [Implemented]</span>
    <span class="badge-brownie">Brownie Points: [Implemented]</span>
    <span class="badge-implemented">Look-Ahead Elimination: [Guaranteed]</span>
    """,
    unsafe_allow_html=True
)
st.divider()

# Sidebar: Controls
st.sidebar.header("⚙️ 1. Asset & Historical Data")
data_source = st.sidebar.selectbox(
    "Select Market Asset",
    ["NIFTY_50_INDEX", "RELIANCE_EQ", "AAPL_TECH", "Upload Custom CSV"]
)

if data_source == "Upload Custom CSV":
    uploaded_file = st.sidebar.file_uploader("Upload CSV (Date, Open, High, Low, Close, Volume)", type=["csv"])
    if uploaded_file is not None:
        try:
            df = load_stock_csv(uploaded_file)
            st.sidebar.success(f"Loaded {len(df)} bars from uploaded CSV.")
        except Exception as e:
            st.sidebar.error(f"Error loading CSV: {e}")
            st.stop()
    else:
        st.info("Please upload a CSV file or choose a preloaded benchmark asset.")
        st.stop()
else:
    sample_file = os.path.join(base_dir, "data", "sample_data", f"{data_source}.csv")
    if os.path.exists(sample_file):
        df = load_stock_csv(sample_file)
    else:
        df = generate_multi_regime_data(symbol=data_source, num_days=1000)

st.sidebar.caption(f"Historical Window: **{df.index[0].date()}** to **{df.index[-1].date()}** ({len(df)} trading days)")

# Sidebar: Strategy Config
st.sidebar.header("🎯 2. Strategy Engine")
strategy_choice = st.sidebar.selectbox(
    "Choose Trading Rule",
    ["Moving Average Crossover", "RSI Mean-Reversion", "Momentum (Rate of Change)", "Machine Learning Regime Classifier"]
)

if strategy_choice == "Moving Average Crossover":
    col_s1, col_s2 = st.sidebar.columns(2)
    with col_s1:
        fast_win = st.number_input("Fast MA", min_value=5, max_value=100, value=20, step=5)
    with col_s2:
        slow_win = st.number_input("Slow MA", min_value=20, max_value=300, value=50, step=10)
    ma_type = st.sidebar.selectbox("MA Formula", ["SMA", "EMA"])
    if fast_win >= slow_win:
        st.sidebar.error("Fast MA must be strictly smaller than Slow MA.")
        st.stop()
    strategy = MovingAverageCrossover(fast_window=int(fast_win), slow_window=int(slow_win), ma_type=ma_type)

elif strategy_choice == "RSI Mean-Reversion":
    rsi_period = st.sidebar.slider("RSI Lookback Period", min_value=5, max_value=30, value=14)
    col_r1, col_r2 = st.sidebar.columns(2)
    with col_r1:
        oversold = st.slider("Oversold (Buy)", min_value=15, max_value=45, value=30)
    with col_r2:
        overbought = st.slider("Overbought (Sell)", min_value=55, max_value=85, value=70)
    strategy = RSIStrategy(period=rsi_period, oversold=oversold, overbought=overbought)

elif strategy_choice == "Momentum (Rate of Change)":
    roc_lookback = st.sidebar.slider("Momentum Lookback (Days)", min_value=5, max_value=90, value=20)
    roc_entry = st.sidebar.slider("Entry Threshold (%)", min_value=0.0, max_value=5.0, value=1.0, step=0.2)
    roc_exit = st.sidebar.slider("Exit Threshold (%)", min_value=-5.0, max_value=2.0, value=0.0, step=0.2)
    strategy = MomentumStrategy(lookback=roc_lookback, entry_threshold=roc_entry, exit_threshold=roc_exit)

else:
    st.sidebar.caption("Random Forest Classifier on In-Sample Lagged Technicals")
    conf_thresh = st.sidebar.slider("ML Upward Confidence Cutoff", min_value=0.50, max_value=0.65, value=0.52, step=0.01)
    rf_depth = st.sidebar.slider("Max Tree Depth (Prevent Overfit)", min_value=2, max_value=8, value=4)
    strategy = MLRegimeStrategy(max_depth=rf_depth, confidence_threshold=conf_thresh)

# Sidebar: Execution Friction
st.sidebar.header("💼 3. Execution Friction & Portfolio")
init_capital = st.sidebar.number_input("Initial Cash ($)", min_value=10_000.0, value=100_000.0, step=10_000.0)
commission_bps = st.sidebar.slider("Brokerage Commission (bps)", min_value=0, max_value=50, value=10, help="10 bps = 0.10%")
slippage_bps = st.sidebar.slider("Adverse Slippage (bps)", min_value=0, max_value=30, value=5, help="5 bps = 0.05%")
risk_free_rate = st.sidebar.number_input("Risk-Free Rate (Annual %)", min_value=0.0, max_value=15.0, value=5.0) / 100.0

comm_pct = commission_bps / 10_000.0
slip_pct = slippage_bps / 10_000.0

# Execute Backtest
simulator = BacktestSimulator(
    initial_capital=init_capital,
    commission_pct=comm_pct,
    slippage_pct=slip_pct
)

with st.spinner("Executing simulation with strict T+1 Open look-ahead elimination..."):
    signals = strategy.generate_signals(df)
    equity_df, trade_df, summary = simulator.run_backtest(df, signals)
    strat_metrics = compute_performance_metrics(equity_df['Portfolio_Value'], trade_df, risk_free_rate)
    bench_metrics = compute_performance_metrics(equity_df['Benchmark_Value'], risk_free_rate=risk_free_rate)

# Top Metrics Row
c1, c2, c3, c4, c5 = st.columns(5)
with c1:
    delta_ret = round(strat_metrics["Total Return (%)"] - bench_metrics["Total Return (%)"], 2)
    st.metric("Total Return", f"{strat_metrics['Total Return (%)']}%", delta=f"{delta_ret}% vs Benchmark")
with c2:
    delta_sharpe = round(strat_metrics["Sharpe Ratio"] - bench_metrics["Sharpe Ratio"], 2)
    st.metric("Sharpe Ratio (Rf=5%)", f"{strat_metrics['Sharpe Ratio']}", delta=f"{delta_sharpe} vs B&H")
with c3:
    mdd_delta = round(bench_metrics["Max Drawdown (%)"] - strat_metrics["Max Drawdown (%)"], 2)
    st.metric("Max Drawdown", f"{strat_metrics['Max Drawdown (%)']}%", delta=f"{mdd_delta}% less risk", delta_color="normal")
with c4:
    st.metric("Win Rate (% Trades)", f"{strat_metrics['Win Rate (%)']}%", f"{strat_metrics['Completed Round Trips']} closed trades")
with c5:
    st.metric("Total Friction Paid", f"${summary['Total_Friction']:,.2f}", f"{summary['Total_Trades']} trade executions")

# Main Navigation Tabs
tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
    "📈 Performance & Backtest",
    "💸 Fee Sensitivity (Brownie Point)",
    "🛡️ In/Out-Of-Sample Overfit Inspector",
    "🔄 Walk-Forward Rolling Analysis",
    "🤖 ML Regimes & Parameter Tuning",
    "📑 Comparison Matrix & Audit Tear Sheet"
])

# ----------------- TAB 1: BACKTEST & BENCHMARK -----------------
with tab1:
    st.subheader("Performance Trajectory vs Buy & Hold Benchmark")
    equity_chart = create_equity_chart(equity_df)
    st.altair_chart(equity_chart, use_container_width=True)
    
    st.subheader("Underwater Risk (Peak-to-Trough Drawdowns)")
    dd_chart = create_drawdown_chart(equity_df)
    st.altair_chart(dd_chart, use_container_width=True)
    
    st.subheader("Quantitative Tear Sheet Comparison")
    comp_data = {
        "Metric": [
            "Cumulative Return (%)", "CAGR (%)", "Annual Volatility (%)",
            "Sharpe Ratio (Annualized)", "Sortino Ratio", "Maximum Drawdown (%)",
            "Calmar Ratio", "Win Rate (%)", "Profit Factor", "Ending Capital ($)"
        ],
        "Strategy": [
            strat_metrics["Total Return (%)"], strat_metrics["CAGR (%)"], strat_metrics["Annual Volatility (%)"],
            strat_metrics["Sharpe Ratio"], strat_metrics["Sortino Ratio"], strat_metrics["Max Drawdown (%)"],
            strat_metrics["Calmar Ratio"], strat_metrics["Win Rate (%)"], strat_metrics["Profit Factor"],
            f"${summary['Ending_Capital']:,.2f}"
        ],
        "Buy & Hold Benchmark": [
            bench_metrics["Total Return (%)"], bench_metrics["CAGR (%)"], bench_metrics["Annual Volatility (%)"],
            bench_metrics["Sharpe Ratio"], bench_metrics["Sortino Ratio"], bench_metrics["Max Drawdown (%)"],
            bench_metrics["Calmar Ratio"], "N/A", "N/A",
            f"${equity_df['Benchmark_Value'].iloc[-1]:,.2f}"
        ]
    }
    st.dataframe(pd.DataFrame(comp_data), use_container_width=True)
    
    with st.expander("🔍 View Complete Trade-by-Trade Audit Log"):
        if not trade_df.empty:
            st.dataframe(trade_df, use_container_width=True)
            csv_trades = trade_df.to_csv(index=False).encode('utf-8')
            st.download_button("📥 Download Trade Log CSV", csv_trades, "trade_audit_log.csv", "text/csv")
        else:
            st.info("No trades triggered within this parameter window.")

# ----------------- TAB 2: FEE SENSITIVITY SHOCK -----------------
with tab2:
    st.subheader("Brownie Point: Impact of Transaction Costs on Profitability")
    st.markdown("""
    Traders frequently design strategies that appear wildly profitable on frictionless paper,
    only to discover in live markets that transaction costs and slippage eradicate all alpha.
    Below is the **Fee Sensitivity Shock**, tracking strategy performance across rising fee levels:
    """)
    fee_shock_df = run_fee_sensitivity_analysis(strategy, df, fee_levels_bps=[0, 5, 10, 20, 35, 50], slippage_bps=slippage_bps, initial_capital=init_capital)
    
    col_f1, col_f2 = st.columns([1, 1])
    with col_f1:
        st.dataframe(fee_shock_df, use_container_width=True)
    with col_f2:
        fee_chart = create_fee_shock_chart(fee_shock_df)
        st.altair_chart(fee_chart, use_container_width=True)
        
    st.info(
        f"💡 **Viva Defense Insight:** At 0 bps (frictionless), strategy return is "
        f"**{fee_shock_df.loc[fee_shock_df['Commission Fee (bps)']==0, 'Total Return (%)'].values[0]}%**. "
        f"At 50 bps, return compresses to **{fee_shock_df.loc[fee_shock_df['Commission Fee (bps)']==50, 'Total Return (%)'].values[0]}%**, "
        f"a total friction extraction of **${fee_shock_df.loc[fee_shock_df['Commission Fee (bps)']==50, 'Total Friction Paid ($)'].values[0]:,.2f}**!"
    )

# ----------------- TAB 3: IN/OUT OF SAMPLE OVERFITTING -----------------
with tab3:
    st.subheader("In-Sample (Train) vs. Out-of-Sample (Test) Validation")
    st.markdown("""
    Evaluating a trading rule strictly on the data it was tuned on creates severe **overfitting bias**.
    AlphaTrial divides the chronological timeline into non-overlapping training and unseen test segments.
    """)
    
    split_pct = st.slider("Training Data Allocation (%)", min_value=50, max_value=85, value=70, step=5)
    robustness = evaluate_train_test_robustness(
        strategy, df, train_ratio=(split_pct/100.0), initial_capital=init_capital, commission_pct=comm_pct, slippage_pct=slip_pct
    )
    
    verdict_color = "#00E676" if not robustness['Is_Overfitted'] else "#FF5252"
    st.markdown(f"""
    <div style="background-color: {verdict_color}22; border-left: 6px solid {verdict_color}; padding: 12px 18px; border-radius: 6px;">
        <h4 style="margin: 0; color: {verdict_color};">Validation Verdict: {robustness['Verdict']}</h4>
        <p style="margin: 4px 0 0 0;">{robustness['Verdict_Detail']}</p>
    </div>
    """, unsafe_allow_html=True)
    st.write("")
    
    c_is1, c_is2, c_is3 = st.columns(3)
    with c_is1:
        st.metric("In-Sample Sharpe", f"{robustness['Train_Metrics']['Sharpe Ratio']}", f"Start to {robustness['Train_Split_Date']}")
    with c_is2:
        st.metric("Out-Of-Sample Sharpe", f"{robustness['Test_Metrics']['Sharpe Ratio']}", f"{robustness['Test_Start_Date']} to End")
    with c_is3:
        st.metric("Sharpe Degradation Index", f"{robustness['Sharpe_Degradation_Pct']}%", "Alert triggered if > 50%")
        
    st.subheader("Side-by-Side In-Sample vs Out-of-Sample Metrics")
    is_oos_table = pd.DataFrame({
        "Metric": ["Return (%)", "CAGR (%)", "Sharpe Ratio", "Sortino", "Max Drawdown (%)", "Win Rate (%)", "Completed Trades"],
        "In-Sample (Training)": [
            robustness['Train_Metrics']['Total Return (%)'], robustness['Train_Metrics']['CAGR (%)'],
            robustness['Train_Metrics']['Sharpe Ratio'], robustness['Train_Metrics']['Sortino Ratio'],
            robustness['Train_Metrics']['Max Drawdown (%)'], robustness['Train_Metrics']['Win Rate (%)'],
            robustness['Train_Metrics']['Completed Round Trips']
        ],
        "Out-of-Sample (Unseen Testing)": [
            robustness['Test_Metrics']['Total Return (%)'], robustness['Test_Metrics']['CAGR (%)'],
            robustness['Test_Metrics']['Sharpe Ratio'], robustness['Test_Metrics']['Sortino Ratio'],
            robustness['Test_Metrics']['Max Drawdown (%)'], robustness['Test_Metrics']['Win Rate (%)'],
            robustness['Test_Metrics']['Completed Round Trips']
        ]
    })
    st.dataframe(is_oos_table, use_container_width=True)

# ----------------- TAB 4: WALK-FORWARD ANALYSIS -----------------
with tab4:
    st.subheader("Walk-Forward / Rolling-Window Strategy Evaluation")
    st.markdown("""
    Walk-forward testing evaluates how well strategy rules adapt as market parameters shift over rolling cycles.
    Each window trains on past bars and tests strictly on the subsequent forward slice.
    """)
    col_w1, col_w2 = st.columns(2)
    with col_w1:
        train_window_bars = st.slider("Train Window Length (Days)", 150, 400, 250, 25)
    with col_w2:
        test_window_bars = st.slider("Out-of-Sample Step (Days)", 40, 120, 60, 10)
        
    wf_data = run_walk_forward_analysis(
        type(strategy),
        strategy.get_params(),
        df,
        train_window=train_window_bars,
        test_window=test_window_bars,
        initial_capital=init_capital,
        commission_pct=comm_pct,
        slippage_pct=slip_pct
    )
    
    if not wf_data.empty:
        st.altair_chart(create_walk_forward_chart(wf_data), use_container_width=True)
        st.dataframe(wf_data, use_container_width=True)
    else:
        st.warning("Insufficient data length for chosen walk-forward window parameters.")
        
    st.subheader("Market Regime Decomposition")
    regime_df = decompose_market_regimes(df, equity_df)
    st.dataframe(regime_df, use_container_width=True)

# ----------------- TAB 5: ML & PARAMETER OPTIMIZATION -----------------
with tab5:
    st.subheader("Parameter Grid Search (In-Sample Training Optimization)")
    st.markdown("Optimize parameters strictly on historical In-Sample data to prevent look-ahead bias.")
    
    col_opt1, col_opt2 = st.columns([1, 2])
    with col_opt1:
        obj_metric = st.selectbox("Optimization Target", ["Sharpe Ratio", "Calmar Ratio", "Total Return (%)"])
        run_opt = st.button("🚀 Run Parameter Optimization")
    
    if run_opt:
        df_train_sub, _ = evaluate_train_test_robustness(strategy, df, train_ratio=0.70)['Train_Equity'], None
        df_train_raw = df.iloc[:int(len(df)*0.70)]
        
        if isinstance(strategy, MovingAverageCrossover):
            p_grid = {"fast_window": [10, 15, 20, 30], "slow_window": [40, 50, 80, 100], "ma_type": ["SMA", "EMA"]}
            strat_key = "MovingAverageCrossover"
        elif isinstance(strategy, RSIStrategy):
            p_grid = {"period": [10, 14, 21], "oversold": [25, 30, 35], "overbought": [65, 70, 75]}
            strat_key = "RSIStrategy"
        else:
            p_grid = {"lookback": [10, 20, 40], "entry_threshold": [0.5, 1.0, 2.0]}
            strat_key = "MomentumStrategy"
            
        opt_res = optimize_parameters(strat_key, df_train_raw, p_grid, objective_metric=obj_metric)
        st.success(f"Optimal Parameters Found: {opt_res['best_row']}")
        st.dataframe(opt_res['results_table'], use_container_width=True)
        
    st.divider()
    st.subheader("Machine Learning Direction & Regime Model")
    st.markdown("""
    AlphaTrial includes a Scikit-Learn **Random Forest Classifier** that predicts upward probability
    using lagged indicators (RSI, 5d/10d/20d returns, rolling volatility, volume anomaly) strictly trained on past bars.
    """)
    ml_test = MLRegimeStrategy(confidence_threshold=0.52)
    _ = ml_test.generate_signals(df)
    feat_imp = ml_test.get_feature_importances()
    if feat_imp:
        st.write("**Feature Importances in Regime Classification:**")
        feat_df = pd.DataFrame(list(feat_imp.items()), columns=["Feature", "Importance"]).sort_values("Importance", ascending=False)
        st.bar_chart(feat_df.set_index("Feature"))

# ----------------- TAB 6: COMPARISON MATRIX & REPORT -----------------
with tab6:
    st.subheader("Multi-Strategy Head-to-Head Comparison")
    st.markdown(f"Running all rule-based strategies across `{data_source}` under identical market conditions:")
    
    all_strats = [
        MovingAverageCrossover(fast_window=20, slow_window=50, ma_type="SMA"),
        RSIStrategy(period=14, oversold=30.0, overbought=70.0),
        MomentumStrategy(lookback=20, entry_threshold=1.0),
        MLRegimeStrategy(confidence_threshold=0.52)
    ]
    
    multi_records = []
    for s in all_strats:
        s_sig = s.generate_signals(df)
        s_eq, s_tr, s_sum = simulator.run_backtest(df, s_sig)
        s_m = compute_performance_metrics(s_eq['Portfolio_Value'], s_tr, risk_free_rate)
        multi_records.append({
            "Strategy": s.name,
            "Total Return (%)": s_m["Total Return (%)"],
            "CAGR (%)": s_m["CAGR (%)"],
            "Sharpe Ratio": s_m["Sharpe Ratio"],
            "Sortino Ratio": s_m["Sortino Ratio"],
            "Max Drawdown (%)": s_m["Max Drawdown (%)"],
            "Calmar Ratio": s_m["Calmar Ratio"],
            "Win Rate (%)": s_m["Win Rate (%)"],
            "Trades": s_m["Completed Round Trips"],
            "Friction Cost ($)": s_sum["Total_Friction"]
        })
    multi_df = pd.DataFrame(multi_records)
    st.dataframe(multi_df, use_container_width=True)
    
    st.divider()
    st.subheader("📑 Executive Strategy Tear Sheet & Defense Report")
    audit_report_text = generate_markdown_audit_report(
        asset_name=data_source,
        strategy_name=strategy.name,
        metrics=strat_metrics,
        benchmark_metrics=bench_metrics,
        friction_summary=summary,
        robustness=robustness
    )
    st.markdown(audit_report_text)
    
    st.download_button(
        "📥 Download Executive Audit Report (Markdown)",
        audit_report_text,
        file_name=f"AlphaTrial_{data_source}_{strategy.name}_Report.md",
        mime="text/markdown"
    )
