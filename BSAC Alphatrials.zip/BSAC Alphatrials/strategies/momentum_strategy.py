"""
Momentum / Rate of Change (ROC) Strategy
- Evaluates N-period momentum: ROC = (Close[t] - Close[t-N]) / Close[t-N]
- Enter Long when ROC > entry_threshold (%)
- Exit to Cash when ROC <= exit_threshold (%)
"""

import pandas as pd
import numpy as np
from .base_strategy import BaseStrategy

class MomentumStrategy(BaseStrategy):
    def __init__(self, lookback: int = 20, entry_threshold: float = 1.0, exit_threshold: float = 0.0):
        name = f"Momentum_{lookback}_thr{entry_threshold}"
        super().__init__(name, {
            "lookback": lookback,
            "entry_threshold": entry_threshold,
            "exit_threshold": exit_threshold
        })
        self.lookback = int(lookback)
        self.entry_threshold = float(entry_threshold)
        self.exit_threshold = float(exit_threshold)

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['Close']
        roc = (close - close.shift(self.lookback)) / (close.shift(self.lookback) + 1e-9) * 100.0
        
        positions = np.zeros(len(df), dtype=int)
        current_pos = 0
        
        for i in range(len(df)):
            val = roc.iloc[i]
            if np.isnan(val):
                positions[i] = 0
                continue
            if val > self.entry_threshold:
                current_pos = 1
            elif val <= self.exit_threshold:
                current_pos = 0
            positions[i] = current_pos
            
        signals = pd.Series(positions, index=df.index, dtype=int)
        signals.iloc[:self.lookback + 1] = 0
        return signals
