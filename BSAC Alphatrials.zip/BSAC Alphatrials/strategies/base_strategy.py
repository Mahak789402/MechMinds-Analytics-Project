"""
AlphaTrial Strategy Base Engine
Standardizes rule-based signal generation across technical and ML strategies.
"""

import pandas as pd
from typing import Dict, Any

class BaseStrategy:
    """
    Abstract Base Class for all rule-based quantitative trading strategies.
    
    Signal Protocol:
    1: Enter / Hold Long Position (100% equity allocation)
    0: Exit to Cash / Flat Position (0% equity allocation, capital preservation)
    """
    def __init__(self, name: str, params: Dict[str, Any] = None):
        self.name = name
        self.params = params or {}

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        """
        Takes OHLCV DataFrame and computes raw position signals [0 or 1].
        
        CRITICAL CONSTRAINT:
        Signals at Bar T must strictly use information available at or before Bar T Close.
        No future data access allowed.
        """
        raise NotImplementedError("Subclasses must implement generate_signals(df).")

    def get_params(self) -> Dict[str, Any]:
        return self.params
