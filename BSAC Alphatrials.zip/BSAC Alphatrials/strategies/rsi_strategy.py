"""
RSI (Relative Strength Index) Mean-Reversion Strategy
- Wilder's 14-period RSI smoothing.
- Enter Long when RSI <= Oversold Threshold (e.g., 30).
- Exit to Cash when RSI >= Overbought Threshold (e.g., 70).
- Holds state until opposing trigger fires.
"""

import pandas as pd
import numpy as np
from .base_strategy import BaseStrategy

def calculate_rsi(series: pd.Series, period: int = 14) -> pd.Series:
    """Calculates Wilder's standard RSI."""
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -1 * delta.clip(upper=0)
    
    avg_gain = gain.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1/period, min_periods=period, adjust=False).mean()
    
    rs = avg_gain / (avg_loss + 1e-9)
    rsi = 100.0 - (100.0 / (1.0 + rs))
    return rsi

class RSIStrategy(BaseStrategy):
    def __init__(self, period: int = 14, oversold: float = 30.0, overbought: float = 70.0):
        name = f"RSI_{period}_{int(oversold)}_{int(overbought)}"
        super().__init__(name, {"period": period, "oversold": oversold, "overbought": overbought})
        self.period = int(period)
        self.oversold = float(oversold)
        self.overbought = float(overbought)
        
        if self.oversold >= self.overbought:
            raise ValueError("Oversold threshold must be strictly less than Overbought.")

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        rsi = calculate_rsi(df['Close'], period=self.period)
        
        positions = np.zeros(len(df), dtype=int)
        current_pos = 0
        
        # State machine across chronological bars
        for i in range(len(df)):
            val = rsi.iloc[i]
            if np.isnan(val):
                positions[i] = 0
                continue
            if val <= self.oversold:
                current_pos = 1
            elif val >= self.overbought:
                current_pos = 0
            positions[i] = current_pos
            
        signals = pd.Series(positions, index=df.index, dtype=int)
        signals.iloc[:self.period + 1] = 0
        return signals
