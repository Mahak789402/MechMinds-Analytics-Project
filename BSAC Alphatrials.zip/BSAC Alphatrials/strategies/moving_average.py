"""
Moving Average Crossover Strategy
- Golden Cross (Fast MA crosses above Slow MA): Buy / Long Signal (1)
- Death Cross (Fast MA crosses below Slow MA): Exit to Cash (0)
"""

import pandas as pd
import numpy as np
from .base_strategy import BaseStrategy

class MovingAverageCrossover(BaseStrategy):
    def __init__(self, fast_window: int = 20, slow_window: int = 50, ma_type: str = "SMA"):
        name = f"{ma_type}_Cross_{fast_window}_{slow_window}"
        super().__init__(name, {"fast_window": fast_window, "slow_window": slow_window, "ma_type": ma_type})
        self.fast_window = int(fast_window)
        self.slow_window = int(slow_window)
        self.ma_type = ma_type.upper()
        
        if self.fast_window >= self.slow_window:
            raise ValueError("Fast window must be strictly smaller than slow window.")

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        close = df['Close']
        if self.ma_type == "EMA":
            fast_ma = close.ewm(span=self.fast_window, adjust=False).mean()
            slow_ma = close.ewm(span=self.slow_window, adjust=False).mean()
        else:
            fast_ma = close.rolling(window=self.fast_window).mean()
            slow_ma = close.rolling(window=self.slow_window).mean()

        # Signal: 1 when fast > slow, 0 otherwise
        signals = pd.Series(0, index=df.index, dtype=int)
        signals[fast_ma > slow_ma] = 1
        
        # Warm-up period must be flat (0)
        signals.iloc[:self.slow_window] = 0
        return signals
