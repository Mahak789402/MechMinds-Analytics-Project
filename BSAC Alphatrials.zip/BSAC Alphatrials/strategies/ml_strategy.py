"""
Machine Learning Regime & Direction Classifier Strategy
Complies with BSAC Advanced Functionality & Look-Ahead Bias rules:
- Strictly splits training vs out-of-sample execution.
- Generates lagged features: RSI, 5d/10d/20d returns, rolling volatility, volume anomaly.
- Trains a Scikit-Learn Random Forest Classifier on In-Sample data to predict forward return direction.
- Can act as a standalone directional strategy or as a regime confirmation filter.
"""

import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from typing import Dict, Any, Optional
from .base_strategy import BaseStrategy
from .rsi_strategy import calculate_rsi

class MLRegimeStrategy(BaseStrategy):
    def __init__(
        self,
        n_estimators: int = 50,
        max_depth: int = 4,
        confidence_threshold: float = 0.52,
        train_split_ratio: float = 0.70,
        random_state: int = 42
    ):
        name = f"ML_Regime_RF_{int(confidence_threshold*100)}pct"
        super().__init__(name, {
            "n_estimators": n_estimators,
            "max_depth": max_depth,
            "confidence_threshold": confidence_threshold,
            "train_split_ratio": train_split_ratio,
            "random_state": random_state
        })
        self.n_estimators = int(n_estimators)
        self.max_depth = int(max_depth)
        self.confidence_threshold = float(confidence_threshold)
        self.train_split_ratio = float(train_split_ratio)
        self.random_state = int(random_state)
        self.model: Optional[RandomForestClassifier] = None
        self.feature_names = []

    def compute_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Constructs strictly backward-looking features for each bar."""
        close = df['Close']
        ret1 = close.pct_change(1)
        ret5 = close.pct_change(5)
        ret10 = close.pct_change(10)
        ret20 = close.pct_change(20)
        
        rsi14 = calculate_rsi(close, 14) / 100.0
        vol20 = ret1.rolling(20).std()
        
        vol_ratio = df['Volume'] / (df['Volume'].rolling(20).mean() + 1e-9)
        
        features_df = pd.DataFrame({
            'ret1': ret1,
            'ret5': ret5,
            'ret10': ret10,
            'ret20': ret20,
            'rsi14': rsi14,
            'vol20': vol20,
            'vol_ratio': vol_ratio
        }, index=df.index)
        
        return features_df

    def generate_signals(self, df: pd.DataFrame) -> pd.Series:
        """
        Trains model on the first (train_split_ratio) portion of the data,
        then evaluates signals across the entire timeseries.
        """
        feats = self.compute_features(df)
        
        # Target: Forward 3-day return is positive
        # Target is shifted backward by 3 for training alignment: target[t] = 1 if close[t+3] > close[t]
        future_ret = (df['Close'].shift(-3) - df['Close']) / df['Close']
        target = (future_ret > 0).astype(int)
        
        valid_idx = feats.dropna().index
        clean_feats = feats.loc[valid_idx]
        clean_target = target.loc[valid_idx]
        
        # Train split cutoff
        split_idx = int(len(clean_feats) * self.train_split_ratio)
        if split_idx < 50:
            # Insufficient data
            return pd.Series(0, index=df.index, dtype=int)
            
        X_train = clean_feats.iloc[:split_idx - 3] # Prevent target look-ahead leakage
        y_train = clean_target.iloc[:split_idx - 3]
        
        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            random_state=self.random_state,
            class_weight='balanced'
        )
        self.model.fit(X_train, y_train)
        self.feature_names = list(clean_feats.columns)
        
        # Generate probabilities for all valid bars using trained model
        prob_up = self.model.predict_proba(clean_feats)[:, 1]
        
        signals_clean = (prob_up >= self.confidence_threshold).astype(int)
        
        signals = pd.Series(0, index=df.index, dtype=int)
        signals.loc[valid_idx] = signals_clean
        
        # Set warm-up to 0
        signals.iloc[:25] = 0
        return signals

    def get_feature_importances(self) -> Dict[str, float]:
        if self.model is None or not hasattr(self.model, 'feature_importances_'):
            return {}
        return dict(zip(self.feature_names, [round(float(v), 4) for v in self.model.feature_importances_]))
